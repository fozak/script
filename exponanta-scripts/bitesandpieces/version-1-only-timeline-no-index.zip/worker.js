export default {
  async fetch(request, env) {
    const url = new URL(request.url);
    const path = url.pathname;
    const method = request.method;

    if (path === '/api/items' && method === 'GET') {
      const { results } = await env.DB.prepare(
        'SELECT id, type, content, position, created_at FROM items ORDER BY position ASC'
      ).all();
      return Response.json(results);
    }

    if (path === '/api/items' && method === 'POST') {
      const { type, content, position } = await request.json();
      if (!['html', 'note'].includes(type) || !content) {
        return new Response('Bad Request', { status: 400 });
      }
      await env.DB.prepare(
        'INSERT INTO items (type, content, position) VALUES (?, ?, ?)'
      ).bind(type, content, position).run();
      return new Response('OK', { status: 201 });
    }

    const del = path.match(/^\/api\/items\/(\d+)$/);
    if (del && method === 'DELETE') {
      await env.DB.prepare('DELETE FROM items WHERE id = ?').bind(Number(del[1])).run();
      return new Response('OK');
    }

    // Everything else → static assets (index.html)
    return env.ASSETS.fetch(request);
  }
};
