# CW BlockNote Editor — Integration Guide

## Files

```
editor-src/
  editor.jsx      ← source (edit this)
  build.mjs       ← build script

editor.js         ← prebuilt output (commit this)
editor.css        ← prebuilt styles (commit this)
```

---

## Build commands

```bash
# Production build (minified, ~2MB)
node editor-src/build.mjs

# Dev build (unminified + sourcemaps, ~4MB)
node editor-src/build.mjs --dev

# Watch mode (rebuilds on change)
node editor-src/build.mjs --watch
```

---

## Add to threads.html

```html
<head>
  <!-- existing styles... -->
  <link rel="stylesheet" href="editor.css">
</head>
```

---

## Replace MarkdownEditor in threads.js

### 1. Load the editor module (once, lazily)

```js
// At top of threads.js — lazy load, only when editor is needed
let _editorModule = null
async function getEditorModule() {
  if (!_editorModule) {
    _editorModule = await import('./editor.js')
  }
  return _editorModule
}
```

### 2. NewPostEditor component

Replace your current `MarkdownEditor` textarea with:

```js
const NewPostEditor = function({ channelName }) {
  const [title, setTitle]   = React.useState('')
  const [body, setBody]     = React.useState('[]')   // BlockNote JSON
  const [postName, setPostName] = React.useState(null) // set after draft create
  const [saving, setSaving] = React.useState(false)
  const editorRef = React.useRef(null)

  // Mount BlockNote after component renders
  React.useEffect(() => {
    let mounted = true

    getEditorModule().then(({ mount }) => {
      if (!mounted) return

      mount({
        containerId: 'bn-new-post-editor',
        initialContent: null,
        pbUrl: CW._config.pb_url,
        pbToken: globalThis.pb?.authStore?.token,
        collectionId: 'item',
        recordId: postName,         // null until draft saved
        onChange: (json) => {
          setBody(json)
        },
      })
    })

    return () => {
      mounted = false
      import('./editor.js').then(({ unmount }) => unmount('bn-new-post-editor'))
    }
  }, [postName])   // remount when recordId becomes available

  const onSaveDraft = async () => {
    if (postName) return  // already created
    setSaving(true)

    const r = await CW.run({
      operation: 'create',
      target_doctype: 'Post',
      input: {
        title: title || 'Untitled',
        body: '[]',
        parent: channelName,
        owner: CURRENT_USER,
        author_name: 'You',
      },
      options: { render: false },
    })

    if (r.success) {
      setPostName(r.target.data.name)
      // editor remounts with recordId — images will now upload to PocketBase
    }
    setSaving(false)
  }

  const onPublish = async () => {
    setSaving(true)

    const name = postName

    if (!name) {
      // Create + publish in one shot (no images)
      await CW.run({
        operation: 'create',
        target_doctype: 'Post',
        input: { title, body, parent: channelName, owner: CURRENT_USER },
        options: { render: false },
      })
    } else {
      // Update body then submit
      await CW.run({
        operation: 'update',
        target_doctype: 'Post',
        query: { where: { name } },
        input: { title, body, _docstatus: 1 },
        options: { render: false },
      })
    }

    setSaving(false)
    // navigate back to feed
    window.dispatchEvent(new CustomEvent('cw:navigate', {
      detail: { view: 'feed', channelName }
    }))
  }

  return ce('div', { className: 'new-post-editor' },
    ce('input', {
      className: 'form-control mb-3',
      placeholder: 'Post title...',
      value: title,
      onChange: e => setTitle(e.target.value),
      onBlur: onSaveDraft,   // create draft on first blur so images have a recordId
    }),

    // BlockNote mounts here
    ce('div', {
      id: 'bn-new-post-editor',
      className: 'bn-editor-container',
      style: { minHeight: 300, border: '1px solid #e2e8f0', borderRadius: 8 }
    }),

    ce('div', { className: 'd-flex gap-2 mt-3' },
      ce('button', {
        className: 'btn btn-primary',
        disabled: saving || !title.trim(),
        onClick: onPublish,
      }, saving ? 'Publishing...' : 'Publish'),
      ce('button', {
        className: 'btn btn-ghost',
        onClick: () => history.back(),
      }, 'Cancel'),
    )
  )
}
```

### 3. PostDetail — render body read-only

Replace markdown render with BlockNote renderer:

```js
// In PostDetail, where you render post.body:
React.useEffect(() => {
  if (!post) return
  getEditorModule().then(({ mountRenderer }) => {
    mountRenderer({
      containerId: `bn-post-${post.name}`,
      content: post.body,
      pbUrl: CW._config.pb_url,
      collectionId: 'item',
      recordId: post.name,
    })
  })
  return () => {
    import('./editor.js').then(({ unmount }) => unmount(`bn-post-${post.name}`))
  }
}, [post?.name])

// In the JSX:
ce('div', { id: `bn-post-${post.name}`, className: 'post-body' })
```

---

## PocketBase — item collection changes needed

Add one field to your `item` collection in PocketBase Admin UI:

| Field name | Type | Max files | Max size | Mime types |
|---|---|---|---|---|
| `images` | File | 10 | 5MB | image/jpeg, image/png, image/gif, image/webp |

No CW schema change needed — `images` is handled outside CW's `data` JSON, 
at the PocketBase record level. The editor uploads directly via PATCH.

---

## Data flow summary

```
User types in BlockNote
  → onChange fires → setBody(json)

User drags image into editor
  → uploadFile() called
  → if no recordId: title blur created draft first
  → PATCH /api/collections/item/records/{postName}  (FormData, images+)
  → PocketBase stores file, returns updated record
  → filename appended to record.images[]
  → PocketBase returns full URL
  → BlockNote renders <img src="..."> inline

User clicks Publish
  → CW.run update with { body: json, _docstatus: 1 }
  → images already on record from upload step
  → single request, no FormData needed (no new files)
```

---

## Post body storage

`body` field stores BlockNote JSON:
```json
[
  { "id": "abc", "type": "heading", "content": [{ "type": "text", "text": "Hello" }] },
  { "id": "def", "type": "paragraph", "content": [{ "type": "text", "text": "World" }] },
  { "id": "ghi", "type": "image", "props": { "url": "https://pb.../img_xyz.jpg" } }
]
```

Images are referenced by their full PocketBase URL — embedded in the JSON.
The `images[]` field on the record is the upload target, not the source of truth for rendering.
